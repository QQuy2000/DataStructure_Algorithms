#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "test/GraphTest.h"
#include "test/TopoSorterTest.h"
