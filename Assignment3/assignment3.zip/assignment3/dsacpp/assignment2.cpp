#define DOCTEST_CONFIG_IMPLEMENT_WITH_MAIN
#include "doctest.h"

#include "test/HeapTest.h"
#include "test/XHashMapTest.h"
#include "test/SortTest.h"
#include "test/SLinkedListSETest.h"
#include "test/DLinkedListSETest.h"
